"""
utils.py — 哈夫曼编码核心算法库
包含：节点定义、频率统计、哈夫曼树构建、编码生成、压缩与解压
"""
 
import heapq
import pickle
from collections import Counter
 
 
# ─────────────────────────────────────────────
# 1. 哈夫曼树节点
# ─────────────────────────────────────────────
 
class HuffmanNode:
    """哈夫曼树节点。叶节点存储字符，内部节点 char=None。"""
 
    def __init__(self, char: str | None, freq: int):
        self.char = char
        self.freq = freq
        self.left: "HuffmanNode | None" = None
        self.right: "HuffmanNode | None" = None
 
    # 优先队列按频率升序排列；频率相同时按字符排列，保证构建结果稳定
    def __lt__(self, other: "HuffmanNode") -> bool:
        if self.freq != other.freq:
            return self.freq < other.freq
        # 叶节点优先于内部节点，字符按字典序
        sc = self.char if self.char is not None else "\uffff"
        oc = other.char if other.char is not None else "\uffff"
        return sc < oc
 
# ─────────────────────────────────────────────
# 2. 频率统计
# ─────────────────────────────────────────────
 
def build_frequency_table(text: str) -> dict[str, int]:
    """
    统计文本中每个字符的出现次数。
    支持中文、英文、全角/半角标点及任意 Unicode 字符。
    直接遍历 Python str（按 Unicode 码点），无需特殊处理。
    """
    text = text.replace('\r\n', '\n').replace('\r', '\n')  # 统一换行符
    if not text:
        raise ValueError("输入文本不能为空")
    return dict(Counter(text))
 
# ─────────────────────────────────────────────
# 3. 构建哈夫曼树
# ─────────────────────────────────────────────
 
def build_huffman_tree(freq_table: dict[str, int]) -> HuffmanNode:
    """
    用最小堆（优先队列）贪心构建哈夫曼树。
    每次取出频率最小的两个节点合并，直到堆中只剩一个根节点。
    特殊情况：只有一种字符时，根节点直接作为叶节点。
    """
    if not freq_table:
        raise ValueError("频率表不能为空")
 
    heap: list[HuffmanNode] = [HuffmanNode(ch, freq) for ch, freq in freq_table.items()]
    heapq.heapify(heap)
 
    # 只有一种字符：构造一个虚拟根，避免编码为空字符串
    if len(heap) == 1:
        only = heapq.heappop(heap)
        root = HuffmanNode(None, only.freq)
        root.left = only
        return root
 
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged = HuffmanNode(None, left.freq + right.freq)
        merged.left = left
        merged.right = right
        heapq.heappush(heap, merged)
 
    return heap[0]
 
# ─────────────────────────────────────────────
# 4. 生成编码表
# ─────────────────────────────────────────────
 
def generate_codes(root: HuffmanNode) -> dict[str, str]:
    """
    前序遍历哈夫曼树，生成每个字符的二进制编码。
    左分支为 '0'，右分支为 '1'。
    """
    codes: dict[str, str] = {}
 
    def _traverse(node: HuffmanNode | None, path: str) -> None:
        if node is None:
            return
        if node.char is not None:          # 叶节点
            codes[node.char] = path or "0" # 根即叶时编码为 "0"
            return
        _traverse(node.left, path + "0")
        _traverse(node.right, path + "1")
 
    _traverse(root, "")
    return codes
 
# ─────────────────────────────────────────────
# 5. 比特串与字节流互转
# ─────────────────────────────────────────────
 
def _text_to_bitstring(text: str, codes: dict[str, str]) -> str:
    """将文本转为 0/1 字符串。"""
    return "".join(codes[ch] for ch in text)
 
 
def _bitstring_to_bytes(bitstring: str) -> tuple[bytes, int]:
    """
    将 0/1 字符串打包为字节。
    末尾不足 8 位时补 0，返回 (字节数据, padding位数)。
    """
    padding = (8 - len(bitstring) % 8) % 8
    bitstring += "0" * padding
 
    result = bytearray()
    for i in range(0, len(bitstring), 8):
        result.append(int(bitstring[i:i + 8], 2))
 
    return bytes(result), padding
 
 
def _bytes_to_bitstring(data: bytes, padding: int) -> str:
    """
    将字节流还原为 0/1 字符串，并去掉末尾补的 padding 位。
    f'{b:08b}' 确保每个字节都补足前导零到 8 位。
    """
    bitstring = "".join(f"{b:08b}" for b in data)
    if padding > 0:
        bitstring = bitstring[:-padding]
    return bitstring
 
# ─────────────────────────────────────────────
# 6. 解码
# ─────────────────────────────────────────────
 
def decode_bitstring(bitstring: str, root: HuffmanNode) -> str:
    """
    沿哈夫曼树逐位匹配，将 0/1 字符串还原为原始文本。
    遇到叶节点即输出字符，然后返回根节点继续解码。
    """
    result = []
    node = root
    for bit in bitstring:
        node = node.left if bit == "0" else node.right
        if node is None:
            raise ValueError("比特流与哈夫曼树不匹配，文件可能已损坏")
        if node.char is not None:   # 到达叶节点
            result.append(node.char)
            node = root             # 回到根节点继续
 
    return "".join(result)
 
 
# ─────────────────────────────────────────────
# 7. 压缩
# ─────────────────────────────────────────────
 
def compress(input_path: str, output_path: str) -> dict:
    """
    读取文本文件，执行哈夫曼压缩，写出 .huf 文件。
 
    .huf 文件格式：
        [pickle序列化的文件头] + [压缩字节流]
    文件头字典包含：
        freq_table : dict[str, int]  — 频率表（用于重建哈夫曼树）
        padding    : int             — 末尾补零位数
 
    返回包含统计信息的字典，供 main.py 展示。
    """
    # 读取原文
    with open(input_path, "r", encoding="utf-8") as f:
        text = f.read()
 
    if not text:
        raise ValueError(f"文件 {input_path} 内容为空，无法压缩")
 
    # 构建树和编码表
    freq_table = build_frequency_table(text)
    root = build_huffman_tree(freq_table)
    codes = generate_codes(root)
 
    # 编码 → 字节流
    bitstring = _text_to_bitstring(text, codes)
    compressed_bytes, padding = _bitstring_to_bytes(bitstring)
 
    # 写出文件
    header = {"freq_table": freq_table, "padding": padding}
    with open(output_path, "wb") as f:
        pickle.dump(header, f)
        f.write(compressed_bytes)
 
    # 统计信息
    import os
    original_size = os.path.getsize(input_path)
    compressed_size = os.path.getsize(output_path)
    total_bits = sum(freq * len(codes[ch]) for ch, freq in freq_table.items())
    avg_code_len = total_bits / len(text)
 
    return {
        "original_size": original_size,
        "compressed_size": compressed_size,
        "ratio": (1 - compressed_size / original_size) * 100,
        "char_count": len(text),
        "unique_chars": len(freq_table),
        "avg_code_len": avg_code_len,
        "codes": codes,
        "freq_table": freq_table,
    }
 
 
# ─────────────────────────────────────────────
# 8. 解压
# ─────────────────────────────────────────────
 
def decompress(input_path: str, output_path: str) -> dict:
    """
    读取 .huf 文件，执行哈夫曼解压，写出还原的文本文件。
    返回包含统计信息的字典。
    """
    with open(input_path, "rb") as f:
        header = pickle.load(f)
        compressed_bytes = f.read()
 
    freq_table: dict[str, int] = header["freq_table"]
    padding: int = header["padding"]
 
    # 重建哈夫曼树
    root = build_huffman_tree(freq_table)
 
    # 字节流 → 比特串 → 原文
    bitstring = _bytes_to_bitstring(compressed_bytes, padding)
    text = decode_bitstring(bitstring, root)
 
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(text)
 
    import os
    return {
        "compressed_size": os.path.getsize(input_path),
        "decompressed_size": os.path.getsize(output_path),
        "char_count": len(text),
    }
 
# ─────────────────────────────────────────────
# 9. 辅助：打印编码表
# ─────────────────────────────────────────────
 
def print_code_table(codes: dict[str, str], freq_table: dict[str, int]) -> None:
    """按频率从高到低打印编码表。"""
    total = sum(freq_table.values())
    sorted_items = sorted(freq_table.items(), key=lambda x: -x[1])
 
    print(f"\n{'字符':<8} {'频率':<8} {'占比':<8} {'编码':<20} {'码长'}")
    print("─" * 56)
    for ch, freq in sorted_items:
        label = repr(ch)           # 对空格、换行等特殊字符友好显示
        code = codes.get(ch, "?")
        print(f"{label:<8} {freq:<8} {freq/total*100:<7.2f}% {code:<20} {len(code)}")